<!--hello.blade.php-->
<h2>Selamat Datang</h2>
<b>semoga sukses dan lancar belajar framework laravel 10.x</b>